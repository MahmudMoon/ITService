package com.example.itservice.common.models

data class AuthResult(val isSuccess: Boolean, val resultData: Any?)
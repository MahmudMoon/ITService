package com.example.itservice.common.models

class Tasks {
}
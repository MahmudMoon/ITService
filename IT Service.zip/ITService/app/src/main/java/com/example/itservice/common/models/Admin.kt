package com.example.itservice.common.models

data class Admin(val uid: String? = null, val fullName: String? = null, val email: String? = null, val password: String? = null )

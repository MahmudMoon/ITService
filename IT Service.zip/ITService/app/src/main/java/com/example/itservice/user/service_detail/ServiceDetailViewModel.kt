package com.example.itservice.user.service_detail

class ServiceDetailViewModel {
}
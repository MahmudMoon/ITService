package com.example.itservice.common.models

data class DbUpdateResult(val isSuccess: Boolean, val data: Any?)

package com.example.itservice.common.models

import java.util.Properties

data class Brand(var id: String? = null,
                 var name: String? = null,
                 var brandImage: String? = null)
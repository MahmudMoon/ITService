package com.example.itservice.user.service_detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.itservice.R

class ServiceDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_service_detail)
    }
}
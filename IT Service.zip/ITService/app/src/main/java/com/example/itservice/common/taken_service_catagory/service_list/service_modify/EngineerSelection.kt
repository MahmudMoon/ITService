package com.example.itservice.common.taken_service_catagory.service_list.service_modify

interface EngineerSelection {
    fun onEngineerSelected(engineerUid: String)
}
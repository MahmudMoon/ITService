package com.example.itservice.common.parts_pack.modify_parts

import androidx.lifecycle.ViewModel

class PartsModifyViewModel: ViewModel() {
}
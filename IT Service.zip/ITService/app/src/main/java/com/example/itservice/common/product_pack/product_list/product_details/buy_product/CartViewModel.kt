package com.example.itservice.user.product_catagory.product_list.product_details.buy_product

import androidx.lifecycle.ViewModel

class CartViewModel: ViewModel() {
}
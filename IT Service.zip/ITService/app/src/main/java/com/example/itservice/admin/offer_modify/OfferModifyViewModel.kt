package com.example.itservice.admin.offer_modify

import androidx.lifecycle.ViewModel

class OfferModifyViewModel: ViewModel() {
}
package com.example.itservice.common.models

data class Enterprise_user(val uid: String? = null,
                           val email: String? = null,
                           val password: String? = null,
                           val tin: String? = null,
                           val companyName: String? = null,
                           val companyAddress: String? = null,
                           val contactNumber: String? = null)

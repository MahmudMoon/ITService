package com.example.itservice.user.ask_service_catagory

import androidx.lifecycle.ViewModel

class UserServiceViewModel: ViewModel() {

}